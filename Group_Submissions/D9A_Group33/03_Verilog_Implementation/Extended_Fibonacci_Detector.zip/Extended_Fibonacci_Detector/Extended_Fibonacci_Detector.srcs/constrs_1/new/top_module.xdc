## ==========================================
## EXTENDED FIBONACCI DETECTOR
## RealDigital Boolean Board - Spartan 7
## Device: XC7S50-CSGA324
## ==========================================

## CLOCK - 100 MHz
set_property -dict { PACKAGE_PIN F14 IOSTANDARD LVCMOS33 } [get_ports { clk }]
create_clock -period 10.000 -name sys_clk [get_ports { clk }]

## RESET - PUSH BUTTON 0
set_property -dict { PACKAGE_PIN J2 IOSTANDARD LVCMOS33 } [get_ports { reset }]

## START - SWITCH 0
set_property -dict { PACKAGE_PIN V2 IOSTANDARD LVCMOS33 } [get_ports { START }]

## ACK - SWITCH 1
set_property -dict { PACKAGE_PIN U2 IOSTANDARD LVCMOS33 } [get_ports { ACK }]

## 5-BIT INPUT - SWITCHES 2 TO 6
set_property -dict { PACKAGE_PIN U1 IOSTANDARD LVCMOS33 } [get_ports { X_in[0] }]
set_property -dict { PACKAGE_PIN T2 IOSTANDARD LVCMOS33 } [get_ports { X_in[1] }]
set_property -dict { PACKAGE_PIN T1 IOSTANDARD LVCMOS33 } [get_ports { X_in[2] }]
set_property -dict { PACKAGE_PIN R2 IOSTANDARD LVCMOS33 } [get_ports { X_in[3] }]
set_property -dict { PACKAGE_PIN R1 IOSTANDARD LVCMOS33 } [get_ports { X_in[4] }]

## FIBONACCI LED - LED 0
set_property -dict { PACKAGE_PIN G1 IOSTANDARD LVCMOS33 } [get_ports { fib_led }]

## NON-FIBONACCI LED - LED 1
set_property -dict { PACKAGE_PIN G2 IOSTANDARD LVCMOS33 } [get_ports { non_fib_led }]

## FSM STATE OUTPUTS
set_property -dict { PACKAGE_PIN F1 IOSTANDARD LVCMOS33 } [get_ports { state[0] }]
set_property -dict { PACKAGE_PIN F2 IOSTANDARD LVCMOS33 } [get_ports { state[1] }]