`timescale 1ns / 1ps

module fsm_controller_tb;

reg clk;
reg reset;
reg START;
reg ACK;
reg fib_detect;

wire fib_led;
wire non_fib_led;
wire [1:0] state;

integer pass_count;
integer fail_count;

localparam IDLE    = 2'b00;
localparam FIB     = 2'b01;
localparam NON_FIB = 2'b10;


// DUT INSTANTIATION

fsm_controller uut (
    .clk(clk),
    .reset(reset),
    .START(START),
    .ACK(ACK),
    .fib_detect(fib_detect),
    .fib_led(fib_led),
    .non_fib_led(non_fib_led),
    .state(state)
);


// CLOCK GENERATION

initial begin
    clk = 0;
    forever #5 clk = ~clk;
end


// CHECK TASK

task check_state;
input [1:0] expected_state;
input expected_fib;
input expected_non_fib;

begin
    #1;

    if ((state === expected_state) &&
        (fib_led === expected_fib) &&
        (non_fib_led === expected_non_fib)) begin

        $display("PASS | STATE=%b | FIB_LED=%b | NON_FIB_LED=%b",
                 state, fib_led, non_fib_led);

        pass_count = pass_count + 1;
    end

    else begin

        $display("FAIL | STATE=%b | EXPECTED STATE=%b",
                 state, expected_state);

        fail_count = fail_count + 1;
    end
end
endtask


// MAIN TEST SEQUENCE

initial begin

    pass_count = 0;
    fail_count = 0;

    reset = 0;
    START = 0;
    ACK = 0;
    fib_detect = 0;

    $display("====================================");
    $display("MOORE FSM CONTROLLER VERIFICATION");
    $display("====================================");


// TEST 1: ASYNCHRONOUS RESET

    #2 reset = 1;

    check_state(IDLE, 0, 0);

    #3 reset = 0;


// TEST 2: FIBONACCI DETECTION

    @(negedge clk);
    START = 1;
    fib_detect = 1;

    @(posedge clk);
    check_state(FIB, 1, 0);


// TEST 3: FIB STATE HOLD

    @(negedge clk);
    START = 0;

    @(posedge clk);
    check_state(FIB, 1, 0);


// TEST 4: FIB ACKNOWLEDGEMENT

    @(negedge clk);
    ACK = 1;

    @(posedge clk);
    check_state(IDLE, 0, 0);


// TEST 5: NON-FIBONACCI DETECTION

    @(negedge clk);
    ACK = 0;
    START = 1;
    fib_detect = 0;

    @(posedge clk);
    check_state(NON_FIB, 0, 1);


// TEST 6: NON-FIB STATE HOLD

    @(negedge clk);
    START = 0;

    @(posedge clk);
    check_state(NON_FIB, 0, 1);


// TEST 7: NON-FIB ACKNOWLEDGEMENT

    @(negedge clk);
    ACK = 1;

    @(posedge clk);
    check_state(IDLE, 0, 0);


// FINAL RESULTS

    $display("====================================");
    $display("TOTAL TESTS : %0d", pass_count + fail_count);
    $display("PASSED      : %0d", pass_count);
    $display("FAILED      : %0d", fail_count);
    $display("====================================");

    $finish;

end

endmodule