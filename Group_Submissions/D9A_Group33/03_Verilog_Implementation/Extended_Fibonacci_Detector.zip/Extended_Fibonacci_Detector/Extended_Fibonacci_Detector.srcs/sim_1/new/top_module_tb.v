`timescale 1ns / 1ps

module top_module_tb;

reg clk;
reg reset;
reg START;
reg ACK;
reg [4:0] X_in;

wire fib_led;
wire non_fib_led;
wire [1:0] state;

integer passed;
integer failed;

reg expected_fib;

// Instantiate Top Module
top_module DUT (
    .clk(clk),
    .reset(reset),
    .START(START),
    .ACK(ACK),
    .X_in(X_in),
    .fib_led(fib_led),
    .non_fib_led(non_fib_led),
    .state(state)
);

// Clock Generation: 10 ns period
initial begin
    clk = 0;
    forever #5 clk = ~clk;
end

// Test Task
task test_input;
    input [4:0] test_value;
    input expected_result;

    begin
        // Apply input
        @(negedge clk);
        X_in = test_value;
        START = 1'b1;

        // Register captures input
        @(negedge clk);
        START = 1'b0;

        // FSM processes comparator result
        @(posedge clk);
        #1;

        expected_fib = expected_result;

        if ((fib_led === expected_fib) &&
            (non_fib_led === !expected_fib)) begin

            $display("PASS: Input=%0d | Fibonacci=%b | State=%b",
                     test_value, fib_led, state);
            passed = passed + 1;
        end
        else begin
            $display("FAIL: Input=%0d | Fibonacci=%b | Non-Fibonacci=%b",
                     test_value, fib_led, non_fib_led);
            failed = failed + 1;
        end

        // Acknowledge result and return to IDLE
        @(negedge clk);
        ACK = 1'b1;

        @(negedge clk);
        ACK = 1'b0;

        @(posedge clk);
        #1;
    end
endtask

// Main Test Sequence
initial begin

    passed = 0;
    failed = 0;

    reset = 1;
    START = 0;
    ACK = 0;
    X_in = 0;

    #20;
    reset = 0;

    // Fibonacci numbers
    test_input(5'd0, 1'b1);
    test_input(5'd1, 1'b1);
    test_input(5'd2, 1'b1);
    test_input(5'd3, 1'b1);
    test_input(5'd5, 1'b1);
    test_input(5'd8, 1'b1);
    test_input(5'd13, 1'b1);
    test_input(5'd21, 1'b1);

    // Non-Fibonacci numbers
    test_input(5'd4, 1'b0);
    test_input(5'd7, 1'b0);
    test_input(5'd15, 1'b0);
    test_input(5'd31, 1'b0);

    // Final Result
    $display("--------------------------------");
    $display("TOTAL PASSED = %0d", passed);
    $display("TOTAL FAILED = %0d", failed);
    $display("--------------------------------");

    if (failed == 0)
        $display("OVERALL RESULT: ALL TESTS PASSED");
    else
        $display("OVERALL RESULT: TESTS FAILED");

    $finish;
end

endmodule