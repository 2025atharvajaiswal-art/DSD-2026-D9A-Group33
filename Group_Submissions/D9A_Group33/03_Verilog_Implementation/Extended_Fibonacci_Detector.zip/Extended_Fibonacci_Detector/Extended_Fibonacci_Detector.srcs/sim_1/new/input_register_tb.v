`timescale 1ns / 1ps

module input_register_tb;

reg clk;
reg reset;
reg START;
reg [4:0] X_in;

wire [4:0] X_reg;

integer pass_count;
integer fail_count;

input_register uut (
    .clk(clk),
    .reset(reset),
    .START(START),
    .X_in(X_in),
    .X_reg(X_reg)
);

// Clock generation
always #5 clk = ~clk;

// Verification task
task check_output;
input [4:0] expected;
begin
    #1;
    if (X_reg === expected) begin
        $display("PASS | X_reg = %0d", X_reg);
        pass_count = pass_count + 1;
    end
    else begin
        $display("FAIL | Expected = %0d | Actual = %0d",
                 expected, X_reg);
        fail_count = fail_count + 1;
    end
end
endtask

initial begin

    clk = 0;
    reset = 0;
    START = 0;
    X_in = 0;

    pass_count = 0;
    fail_count = 0;

    $display("================================");
    $display("5-BIT INPUT REGISTER TEST");
    $display("================================");

    // TEST 1: Asynchronous Reset
    #2 reset = 1;
    check_output(5'd0);

    #2 reset = 0;

    // TEST 2: Load Fibonacci number 13
    @(negedge clk);
    X_in = 5'd13;
    START = 1;

    @(posedge clk);
    check_output(5'd13);

    // TEST 3: Hold previous value
    @(negedge clk);
    START = 0;
    X_in = 5'd7;

    @(posedge clk);
    check_output(5'd13);

    // TEST 4: Load Fibonacci number 21
    @(negedge clk);
    START = 1;
    X_in = 5'd21;

    @(posedge clk);
    check_output(5'd21);

    // TEST 5: Load maximum 5-bit value
    @(negedge clk);
    X_in = 5'd31;

    @(posedge clk);
    check_output(5'd31);

    // FINAL REPORT
    $display("================================");
    $display("TOTAL TESTS : %0d", pass_count + fail_count);
    $display("PASSED      : %0d", pass_count);
    $display("FAILED      : %0d", fail_count);
    $display("================================");

    $finish;

end

endmodule